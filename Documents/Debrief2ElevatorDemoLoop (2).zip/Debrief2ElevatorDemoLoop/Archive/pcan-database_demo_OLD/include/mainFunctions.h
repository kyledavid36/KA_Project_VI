#ifndef MAIN_FUNCTIONS
#define MAIN_FUNCTIONS

int menu();
int chooseID();
int chooseMsg();
int HexFromFloor(int floorVal);
int FloorFromHex(int Hex);

#endif
